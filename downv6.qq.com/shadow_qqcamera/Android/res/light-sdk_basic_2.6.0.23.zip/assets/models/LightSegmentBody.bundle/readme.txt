High middle low文件夹分别对应多输入人体分割的大、中、小模型
其中iOS没有小模型（low）


high:
humanseg_v5.5.0_2021.01.27_xcp-up-4input-256x256-big-0126finv2-tnn


middle:
humanseg_v5.5.0_2021.01.27_mnv-v2-4input-192x192-middle-0126finv2-49-tnn


low:
LightSegmentBody.rapidmodel -> 人像分割_humanseg_v5.2.0_2020.12.04_xcp-v3-4input-160x160-small-exp1125-199.opt.tnnm.wmc
LightSegmentBody.rapidproto -> 人像分割_humanseg_v5.2.0_2020.12.04_xcp-v3-4input-160x160-small-exp1125-199.opt.tnnp.wmc