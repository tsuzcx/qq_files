High middle low文件夹分别对应多输入人体分割的大、中、小模型
其中iOS没有小模型（low）


high:
humanseg_v5.5.0_2021.01.27_xcp-up-4input-256x256-big-0126finv2-tnn


middle:
humanseg_v5.5.0_2021.01.27_mnv-v2-4input-192x192-middle-0126finv2-49-tnn


low:
LightSegmentBody.rapidmodel -> tnn_BodySeg_身体分割_v5.7.1_202110091836_1005_xcp_spconv_v3_144x144_64.opt.tnnm
LightSegmentBody.rapidproto -> tnn_BodySeg_身体分割_v5.7.1_202110091836_1005_xcp_spconv_v3_144x144_64.opt.tnnp
